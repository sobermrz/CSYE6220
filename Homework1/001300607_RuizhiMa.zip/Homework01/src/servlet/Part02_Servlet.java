package servlet;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayRequestHeader
 */
@WebServlet("/Part02_Servlet")
public class Part02_Servlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//getHeaderName method
		test(request);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	// use getHeaderName method
	public void test01(HttpServletRequest request) {
		Enumeration<String> e = request.getHeaderNames();

		while (e.hasMoreElements()) {
			String headerNmae = e.nextElement();
			System.out.println(headerNmae);
		}
	}
	
	public void test(HttpServletRequest request) {
		Enumeration<String> e = request.getHeaderNames();
		while(e.hasMoreElements()) {
			String headerName = e.nextElement();
			Enumeration<String> headerValues = request.getHeaders(headerName);
			while(headerValues.hasMoreElements()) {
				System.out.println(headerName + ":" + headerValues.nextElement());
			}
		}
		
	}

}
