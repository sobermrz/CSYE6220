package servlet;

import java.io.IOException;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet get data from jsp
 */
@WebServlet("/part03_login_do")
public class Part03_Servlet extends HttpServlet {    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	//get values
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String image = request.getParameter("image");
        String gender = request.getParameter("gender");
        String country = request.getParameter("country");
        String[] hobbies = request.getParameterValues("hobby"); 
        String address = request.getParameter("address");
        
        System.out.println(email);
        System.out.println(password);
        System.out.println(confirmPassword);
        System.out.println(image);
        System.out.println(gender);
        System.out.println(country);
        for (int i = 0; i < hobbies.length; i++) {
			System.out.println(hobbies[i] + "\t");
		}  
        System.out.println(address);
    }

}