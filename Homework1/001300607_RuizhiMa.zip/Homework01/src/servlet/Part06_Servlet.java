package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.io.IOException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class Part06_Servlet
 */
@WebServlet("/part06_do")
public class Part06_Servlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html");
	    PrintWriter out = resp.getWriter();
	    
	    String qn = req.getParameter("qn");
	    
	    if(qn.equals("1"))
	    {
	        out.println("<!doctype HTML>");
	        out.println("<html>");
	        out.println("<head>");
	        out.println("<title>Online Quiz</title>");
	        out.println("</head>");
	        out.println("<body>");
	        out.println("<form action='part06_do' method='post'>");  // out.println("<form action='part06/enter' method='post'>");
	        
	        out.println("Please enter the name of child number1<input type='text' name='question1'/><br/>");
	        
	        out.println("Please enter the name of child number2<input type='text' name='question2' /><br/>"); 

	        out.println("Please enter the name of child number3<input type='text' name='question3' /><br/>");
	        
	        out.println("<input type='hidden' name='qn' value='2'/>");
	        out.println("<input type='submit' value='SUBMIT Query'/>");
	        out.println("</form>");
	        out.println("</body>");
	        out.println("</html>");
	        out.close();
	    }
	    
	}

	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html");
	    PrintWriter out = resp.getWriter();
	    
	    String qn = req.getParameter("qn");
	    //HttpSession session = req.getSession(true);
	     if(qn.equals("2")){
	    	out.println("<html>");
	    	
	        out.println("<head>");
	        out.println("<title>Online Quiz</title>");
	        out.println("</head>");
	        
	        out.println("<body>");

	        String answer1 =  req.getParameter("question1");
	        String answer2 =  req.getParameter("question2");
	        String answer3 =  req.getParameter("question3");
	        
	        //out.println("<form action='part06/display' method='post'>"); 
	        out.println("<ul>");
	        out.println("<li>Your childen's names are:</li>");
	        out.println("<li>" + answer1 +"</li>");  // out.println("<li>Answer1 : " + session.getAttribute("answer1") +"</li>");
	        out.println("<li>" + answer2 +"</li>");  // out.println("<li>Answer2 : " + session.getAttribute("answer2") +"</li>");
	        out.println("<li>" + answer3 +"</li>");  // out.println("<li>Answer3 : " + session.getAttribute("answer3") +"</li>");
	        
	        out.println("</ul>");
	        //out.println("</form>");
	        out.println("</body>");
	        out.println("</html>");
	    }
	}

}