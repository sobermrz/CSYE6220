package servlet;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet  Servlet get data from jsp
 */
@WebServlet("/part04_login_do")
public class Part04_Servlet extends HttpServlet {    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	  
    	  Enumeration<String> e = request.getParameterNames();
    	  while (e.hasMoreElements()) {
    		  
			String name = (String) e.nextElement();
			String[] values = request.getParameterValues(name);
			
			for (int i = 0; i < values.length; i++) {
				System.out.println(name + "=" + values[i]);
			}

		}
    }

}